CREATE PROCEDURE myproc()
  begin 
declare num int; 
set num=1; 
while num < 3000 
do 
INSERT INTO point_prize_pool(
point_prize_pool.prizeid,
point_prize_pool.release_time,
point_prize_pool.balance,
point_prize_pool.version,
point_prize_pool.jdcardid)
values(15,'2017-01-04',1,1,0); 
set num=num+1;
end while; 
 end;
