CREATE PROCEDURE pro_ImportUserAndGroupWithDC()
  BEGIN
INSERT into user_log(logName,logContent,remark,createDate,creator)	VALUES('start_pro','执行存储过程导入数据','开始执行',NOW(),'Sys_Z');
	
	TRUNCATE TABLE user_tmp;
	-- 将数据从empinfofromad_tmp中取出导入到user_tmp中，其中empinfofromad_tmp中的msExchExtensionAttribute16表示的就是local name;givenName表示的是FristName；
	INSERT into user_tmp(
					ITCode,						firstnameen,						firstname,  
					position,					positionen,							organization,	
					organizationen,		telephone,							mobile,	

					ParentITCode,			cityName,								email,
					displayName,			givenName,							icon,
					employeeType,			ad_type,enterprise,`status`,temp
					 )
	
	select 	sAMAccountName,		displayName,						msExchExtensionAttribute16, 	
					title,						title,									department,	
					department,				telephoneNumber,				mobile,
	
					managerLoginID,		L,											mail,
					displayName,			givenName,							CONCAT('ADPhotos/',sAMAccountName,'.jpg'),
					employeeType,			ad_type,enterprise,`status`,temp
	from empinfofromad_tmp; 
-- where employeeType='Regular Employee' OR employeeType='Contractor' OR employeeType='Vendor' or sAMAccountName in('szpgh','hrsupport','yinzx1','liqy10','xiecs1','liuming10','zhouchao4','hanjing3','limeng7','liyf13','dansj1','xieqp','hanxd1','heph1','dengyh1','5000'); 
-- 'cochat','mim','ibassistant','ccassistant','aoassistant','dmassistant','movo','gltcomms','seclipc','security2';
	INSERT into user_log(logName,logContent,remark,createDate,creator)	
	VALUES('insert_user_tmp',CONCAT('清空user_tmp表之后，将AD数据注入到user_tmp表中，影响行数：',ROW_COUNT()),'步骤1',NOW(),'Sys_Z');
	
	-- 如果localName（msExchExtensionAttribute16）无值，则显示firstName（givenName）；
	-- update user_tmp set firstname=givenName where firstname='' OR firstname is NULL;
	
	-- 如果上级是本身，将上级更新为空；
	UPDATE user_tmp SET ParentITCode=NULL where ITCode=ParentITCode;
		

-- ###############################################将数据从User_temp整合到User中
	-- 先修改数据		
	UPDATE `user` as u,user_tmp as t SET 
		-- User表					empinfofromad_tmp表
		u.firstname				=t.firstname,
		u.firstnameen			=t.firstnameen,
		u.position				=t.position,
		u.positionen			=t.positionen,				-- 工作职位英文
		u.organization		=t.organization, -- e.Department,			-- 组织中文名称
		u.organizationen	=t.organizationen, -- e.Department,			-- 组织英文名称
		u.telephone				=t.telephone,		-- 工作电话
		u.mobile					=t.mobile,		-- 移动电话
		u.parentCode			=t.ParentITCode,		-- 上级的itcode
		u.cityName				=t.cityName, 						-- 所在城市名称
		-- u.icon						=t.icon,
		u.email						=t.email,
		u.ad_type					=t.ad_type,
		u.enterprise					=t.enterprise,
		u.user_status					=t.status,
		u.svp 						=t.temp

	WHERE u.itcode=t.ITCode;
	INSERT into user_log(logName,logContent,remark,createDate,creator)	
	VALUES('update_user',CONCAT('根据user_tmp更新user表，影响行数：',ROW_COUNT()),'步骤2-1',NOW(),'Sys_Z');

	-- 后插入-- 查询empinfofromad_tmp中有而User表中没有的数据
	insert into `user`(
					itcode,								sex,									position,							telephone,					firstname,				
					positionen,						organization,					organizationen,				address,						firstnameen,	
					mobile,								parentId,							parentCode,						username,						password,
		
					createDate,						loginCount,						currLogin,						currLoginIP,				lastLogin,			
					lastLoginIP,					userType,							icon,									iconUpdateTime,			latitude,			
					longitude,						cityName,							district,							province,						street,				
					street_number,				memo,									email,								ad_type,				    enterprise,user_status
			-- userId,lastname,company,showMobile,inviteId,inviteCodeId,status,articleAdmin,invitePerm,mailStatus,deletePerm,allowPosition,sysAdmin,lastChkETime,chkATime,versionName,companyId
			)
	select 	t.ITCode,							NULL,									t.position,						t.telephone,				t.firstname,							
					t.positionen,					t.organization,				t.organizationen,			'',									t.firstnameen,
					t.mobile,							NULL,									t.ParentITCode,				t.ITCode,						NULL,	
			
					now(),								0,										NULL,									'',									null,				
					'',										NULL,									t.icon,								NOW(),							null,				
					null,									t.cityName,						'',										'',									'',					
					'',										'',										t.email,							t.ad_type,					t.enterprise,t.`status`
	from user_tmp as t left join `user` as u on t.ITCode=u.itcode where u.userId is null; 
	INSERT into user_log(logName,logContent,remark,createDate,creator)	
	VALUES('insert_user',CONCAT('根据user_tmp新增user表数据，影响行数：',ROW_COUNT()),'步骤2-2',NOW(),'Sys_Z');

	-- 修改User中的parentId，如果上级发生的变化，对应的parentid也应该变化。
	UPDATE `user` set parentId=NULL where parentCode='' OR parentCode is NULL;
	UPDATE `user` as a,`user` as b	set a.parentId=b.userId	where a.parentCode=b.itcode;
	INSERT into user_log(logName,logContent,remark,createDate,creator)	
	VALUES('insert_user_parentId',CONCAT('修改user表中的ParentId的值，影响行数：',ROW_COUNT()),'步骤3',NOW(),'Sys_Z');
	
	UPDATE `user` SET firstnameen='Cochat',firstname='乐聊小助手' where itcode='cochat';
	

	INSERT into user_log(logName,logContent,remark,createDate,creator)	
	VALUES('pro_ImportUserAndGroupWithDC','存储过程执行完毕','结束！',NOW(),'Sys_Z');
END;
