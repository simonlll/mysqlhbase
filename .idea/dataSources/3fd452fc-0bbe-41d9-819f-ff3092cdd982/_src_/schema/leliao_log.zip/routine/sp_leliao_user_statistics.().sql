CREATE PROCEDURE sp_leliao_user_statistics()
  BEGIN
	#Routine body goes here...
	-- 使用用户数/用户使用次数  近30天数据
	SELECT DATE(dt) as dt,COUNT(DISTINCT uid) as itcode,COUNT(1) as count FROM app_log 
	where LENGTH(uid)>1 and DATE_SUB(CURDATE(),INTERVAL 6 DAY)<= DATE(dt) AND url<>'/attendance/getAllAttendance'
	GROUP BY DATE(dt)
	ORDER BY DATE(dt) desc;
END;
