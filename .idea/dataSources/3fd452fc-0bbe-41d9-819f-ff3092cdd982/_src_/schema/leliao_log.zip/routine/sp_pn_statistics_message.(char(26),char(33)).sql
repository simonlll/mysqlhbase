CREATE PROCEDURE sp_pn_statistics_message(IN pn0 CHAR(26), IN pn1 CHAR(33))
  BEGIN
	#Routine body goes here...
	
	select '日' as dt,COUNT(DISTINCT uid) as itcodes,COUNT(1) as number,ROUND(TRUNCATE(COUNT(1)/COUNT(DISTINCT uid),2),0) as average,
	(select COUNT(DISTINCT uid) from app_log where url='/fc_share_url' and v like `pn0` and v not like '%?token=%' and DATE(NOW())-DATE(dt)=1) as share_itcodes,
	(select COUNT(1) from app_log where url='/fc_share_url' and v like `pn0` and v not like '%?token=%' and DATE(NOW())-DATE(dt)=1) as share_number
	from app_log 
	where  DATE(NOW())-DATE(dt)=1 and url='/pn_msg_view_log' and v like `pn1` and v not like '%?token=%';

	select '周' as dt,COUNT(DISTINCT uid) as itcodes,COUNT(1) as number,ROUND(TRUNCATE(COUNT(1)/COUNT(DISTINCT uid),2),0) as average,
	(select COUNT(DISTINCT uid) from app_log where url='/fc_share_url' and v like `pn0` and v not like '%?token=%' and DATE_SUB(CURDATE(),INTERVAL 7 DAY)<=DATE(dt)) as share_itcodes,
	(select COUNT(1) from app_log where url='/fc_share_url' and v like `pn0` and v not like '%?token=%' and DATE_SUB(CURDATE(),INTERVAL 7 DAY)<=DATE(dt)) as share_number
	from app_log 
	where DATE_SUB(CURDATE(),INTERVAL 7 DAY)<=DATE(dt) and url='/pn_msg_view_log' and v like `pn1` and v not like '%?token=%';

	select '月' as dt,COUNT(DISTINCT uid) as itcodes,COUNT(1) as number,ROUND(TRUNCATE(COUNT(1)/COUNT(DISTINCT uid),2),0) as average,
	(select COUNT(DISTINCT uid) from app_log where url='/fc_share_url' and v like `pn0` and v not like '%?token=%' and DATE_SUB(CURDATE(),INTERVAL 30 DAY)<=DATE(dt)) as share_itcodes,
	(select COUNT(1) from app_log where url='/fc_share_url' and v like `pn0` and v not like '%?token=%' and DATE_SUB(CURDATE(),INTERVAL 30 DAY)<=DATE(dt)) as share_number
	from app_log 
	where DATE_SUB(CURDATE(),INTERVAL 30 DAY)<=DATE(dt) and url='/pn_msg_view_log' and v like `pn1` and v not like '%?token=%';


	select DATE(app_a.dt) as dt,app_a.uid,app_a.v,COUNT(DISTINCT app_a.uid) as itcodes,COUNT(1) as number,ROUND(TRUNCATE(COUNT(1)/COUNT(DISTINCT uid),2),0) as average,
	(select COUNT(DISTINCT app_b.uid) from app_log as app_b where app_b.url='/fc_share_url' and app_b.v like `pn0` and v not like '%?token=%' and DATE_SUB(CURDATE(),INTERVAL 30 DAY)<=DATE(app_b.dt)) as share_itcodes,
	(select COUNT(1) from app_log as app_c where app_c.url='/fc_share_url' and app_c.v like `pn0` and v not like '%?token=%' and DATE_SUB(CURDATE(),INTERVAL 30 DAY)<=DATE(app_c.dt)) as share_number
	from app_log as app_a
	where DATE_SUB(CURDATE(),INTERVAL 30 DAY)<=DATE(app_a.dt) and app_a.url='/pn_msg_view_log' and app_a.v like `pn1` and v not like '%?token=%'
	GROUP BY DATE(app_a.dt)
	ORDER BY DATE(app_a.dt) DESC;
END;
