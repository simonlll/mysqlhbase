CREATE PROCEDURE sp_pn_statistics_message_create(IN pn0 CHAR(26))
  BEGIN
	#Routine body goes here...
	-- and DATE_SUB(CURDATE(),INTERVAL 30 DAY)<=DATE(dt) 2015-07-01 改成一年
	select date_format(dt,'%Y-%m-%d %T') as 'dt',uid,v from app_log 
		where (url='/pn_msg_create' or url='/pna/pn_msg_create') and DATE_SUB(CURDATE(),INTERVAL 1 YEAR)<=DATE(dt) and  v like `pn0` and v like '%"msg_type":"message"%' ORDER BY dt DESC;
/*select date_format(dt,'%Y-%m-%d %T') as 'dt',uid,v from app_log_2016_10_25 
		where (url='/pn_msg_create' or url='/pna/pn_msg_create') and  v like `pn0` and v like '%"msg_type":"message"%'  ORDER BY dt DESC LIMIT 1;*/
END;
