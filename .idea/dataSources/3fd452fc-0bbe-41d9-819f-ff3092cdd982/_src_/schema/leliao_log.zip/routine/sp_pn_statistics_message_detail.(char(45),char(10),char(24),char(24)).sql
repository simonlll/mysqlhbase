CREATE PROCEDURE sp_pn_statistics_message_detail(IN pn0    CHAR(45), IN strDate CHAR(10), IN msgId0 CHAR(24),
                                                 IN msgId1 CHAR(24))
  BEGIN
	#Routine body goes here...
	/*select uid,v,COUNT(1) from app_log
	where DATE(dt)=`strDate` and (url='/pn_msg_create' or url='/pna/pn_msg_create') and v like '%"msg_type":"message"%' and v LIKE `pn0`
	GROUP BY v;*/
	select 
	(select COUNT(1) from app_log  
	where DATE(dt)=`strDate` and (url='/pn_msg_create' or url='/pna/pn_msg_create') 
	and v like `msgId1` and v LIKE `pn0`)as push_number,
	(select COUNT(DISTINCT uid) from app_log  
	where DATE(dt)=`strDate` and (url='/pn_msg_create' or url='/pna/pn_msg_create') 
	and v like `msgId1` and v LIKE `pn0`)as push_itcodes,
	(select COUNT(1) from app_log 
	where DATE(dt)=`strDate` and (url='/pn_msg_view_log' or url='/pna/pn_msg_view_log') 
	and v like `msgId0` and v LIKE `pn0`)as view_number,
	(select COUNT(DISTINCT uid) from app_log 
	where DATE(dt)=`strDate` and (url='/pn_msg_view_log' or url='/pna/pn_msg_view_log') 
	and v like `msgId0` and v LIKE `pn0`)as view_itcodes,
	(SELECT COUNT(1) from app_log 
	where url='/fc_share_url' and v like `msgId0` and v LIKE `pn0`)as share_number,
	(select COUNT(DISTINCT uid) from app_log 
	where url='/fc_share_url' and v like `msgId0` and v LIKE `pn0`)as share_itcodes;
END;
