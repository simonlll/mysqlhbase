CREATE PROCEDURE sp_pn_statistics_message_list(IN strDate CHAR(10), IN pn0 CHAR(45))
  BEGIN
	#Routine body goes here...
	select DISTINCT v,'pn_msg_create' as type from app_log
	where DATE(dt)=`strDate` and (url='/pn_msg_create' or url='/pna/pn_msg_create') and v LIKE `pn0`
	UNION ALL
	select DISTINCT v,'pn_msg_view_log' as type from app_log
	where DATE(dt)=`strDate` and (url='/pn_msg_view_log' or url='/pna/pn_msg_view_log') and v LIKE `pn0`
	GROUP BY v;
END;
