CREATE PROCEDURE sp_pn_statistics_message_list2(IN pn0 CHAR(26))
  BEGIN
	#Routine body goes here...
	select date_format(dt,'%Y-%m-%d') as dt,v,'pn_msg_create' as type from app_log
	where DATE_SUB(CURDATE(),INTERVAL 30 DAY)<=DATE(dt) and (url='/pn_msg_create' or url='/pna/pn_msg_create') and v LIKE `pn0`
	UNION ALL
	select date_format(dt,'%Y-%m-%d') as dt,v,'pn_msg_view_log' as type from app_log
	where DATE_SUB(CURDATE(),INTERVAL 30 DAY)<=DATE(dt) and (url='/pn_msg_view_log' or url='/pna/pn_msg_view_log') and v LIKE `pn0`
	UNION ALL
	select date_format(dt,'%Y-%m-%d') as dt,v,'fc_share_url' as type from app_log
	where DATE_SUB(CURDATE(),INTERVAL 30 DAY)<=DATE(dt) and (url='/fc_share_url' or url='/pna//fc_share_url') and v LIKE `pn0`;
END;
