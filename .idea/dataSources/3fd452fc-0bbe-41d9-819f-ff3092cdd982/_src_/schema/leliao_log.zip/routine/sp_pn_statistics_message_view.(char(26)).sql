CREATE PROCEDURE sp_pn_statistics_message_view(IN pn0 CHAR(26))
  BEGIN
	#Routine body goes here...
	-- and DATE_SUB(CURDATE(),INTERVAL 30 DAY)<=DATE(dt) 015-07-01 改成一年
	select date_format(dt,'%Y-%m-%d %T') as 'dt',uid,v from app_log 
		where (url='/pn_msg_view_log' or url='/pna/pn_msg_view_log') and DATE_SUB(CURDATE(),INTERVAL 1 YEAR)<=DATE(dt) and v like `pn0` ORDER BY dt DESC;
/*	select date_format(dt,'%Y-%m-%d %T') as 'dt',uid,v from app_log_2016_10_25 
		where (url='/pn_msg_view_log' or url='/pna/pn_msg_view_log') and  v like `pn0` and dt>'2016-06-01'  ORDER BY dt DESC LIMIT 1;*/
END;
