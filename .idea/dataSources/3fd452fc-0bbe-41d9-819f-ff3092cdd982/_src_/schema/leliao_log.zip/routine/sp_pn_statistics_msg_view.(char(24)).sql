CREATE PROCEDURE sp_pn_statistics_msg_view(IN pn0 CHAR(24))
  BEGIN
	/*昨天数据*/
	select '日' as dt,COUNT(DISTINCT uid) as itcodes,COUNT(1) as number from pn_msg_view_log
	where pn=`pn0`  and DATE(NOW())-DATE(dt)=1;

	/*7天数据*/
	select '周' as dt,COUNT(DISTINCT uid) as itcodes,COUNT(1) as number from pn_msg_view_log
	where pn=`pn0`  and DATE_SUB(CURDATE(),INTERVAL 7 DAY)<=DATE(dt);

	/*30天数据*/
	select '月' as dt,COUNT(DISTINCT uid) as itcodes,COUNT(1) as number from pn_msg_view_log
	where pn=`pn0`  and DATE_SUB(CURDATE(),INTERVAL 30 DAY)<=DATE(dt);

	/*30天数据列表*/
	select DATE(dt) as dt,COUNT(DISTINCT uid) as itcodes,COUNT(1) as number from pn_msg_view_log
	where pn=`pn0`  and DATE_SUB(CURDATE(),INTERVAL 30 DAY)<=DATE(dt)
	GROUP BY DATE(dt)
	ORDER BY DATE(dt) DESC;

END;
