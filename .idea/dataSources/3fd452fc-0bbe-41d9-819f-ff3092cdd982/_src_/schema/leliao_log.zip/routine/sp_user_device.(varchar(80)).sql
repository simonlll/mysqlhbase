CREATE PROCEDURE sp_user_device(IN itcode VARCHAR(80))
  BEGIN
	#Routine body goes here...
	UPDATE user_device as u,
	(SELECT baiduid,channelid,android,`status`,apk_version,logout_date FROM user_device_tmp) as t
	set u.channelid=t.channelid,u.android=t.android,
	u.`status`=t.`status`,u.modifyOn=NOW(),u.logout_date=t.logout_date
	where u.baiduid=t.baiduid;

	INSERT into web_log(itcode,dt,op,content) 
	VALUES(`itcode`,NOW(),'update',CONCAT('批量修改乐聊安装用户，影响行数',ROW_COUNT()));

	INSERT INTO user_device(baiduid,itcode,channelid,imei,model,android,`status`
	,modifyOn,createOn,firstname,firstnameen,apk_version,logout_date)
		(select DISTINCT t.baiduid,t.itcode,
		t.channelid,t.imei,t.model,t.android,t.status,
		t.modifyOn,t.createOn,
		t.firstname,t.firstnameen,
		t.apk_version,t.logout_date 
	from user_device_tmp as t
	LEFT JOIN user_device as u on t.baiduid<>u.baiduid);

	INSERT into web_log(itcode,dt,op,content) 
	VALUES(`itcode`,NOW(),'Insert',CONCAT('批量插入乐聊安装用户，影响行数',ROW_COUNT()));
	/*TRUNCATE TABLE user_device_tmp;*/
END;
